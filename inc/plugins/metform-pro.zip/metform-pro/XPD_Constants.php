<?php

namespace MetForm_Pro;


class XPD_Constants {

	const RETURN_OKAY = 'ok';
	const RETURN_NOT_OKAY = 'not ok';

}